package project4_starter;

public class Demo {

	public static void main(String[] args) {
		
		CallStackValidator tester = new CallStackValidator();
		
		System.out.println("The following should all be true:\n");
		System.out.println(tester.validate("A calls B B calls C C halts B halts A halts"));
	
		System.out.println(tester.validate("A calls B B calls C C calls D D halts C calls E E halts C halts B halts A halts"));

		System.out.println(tester.validate("A calls A A halts A halts"));

		System.out.println(tester.validate("main calls functionA functionA calls testMe testMe halts functionA calls runRun runRun halts functionA halts main halts"));
		
		System.out.println("\nThe following should all be false:\n");
		
		System.out.println(tester.validate("main calls A A calls B A calls C B halts C halts A halts main halts"));
		
		System.out.println(tester.validate("A calls B B halts"));
		
		System.out.println(tester.validate("A calls B A calls C C halts B halts A halts"));
		
		CapitalGainsCalculator calc = new CapitalGainsCalculator();
		System.out.println("\nThe following should be 940:");
		System.out.println(calc.getCapitalGains("buy 100 shares at 20 dollars each buy 20 shares at 24 dollars each buy 200 shares at 36 dollars each sell 150 shares at 30 dollars each"));
		
		System.out.println("\nThe following should be -35:");
		System.out.println(calc.getCapitalGains("buy 5 shares at 12 dollars each buy 8 shares at 10 dollars each sell 1 share at 30 dollars each sell 5 shares at 1 dollars each buy 10 shares at 5 dollars each"));
			
	}

}
