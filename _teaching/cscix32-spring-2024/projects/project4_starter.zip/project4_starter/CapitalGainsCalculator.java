package project4_starter;


public class CapitalGainsCalculator {
	
	public double getCapitalGains(String transactions) {
		
		return 0;
	}
	

}
