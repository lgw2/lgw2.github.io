package project4_starter;

import java.util.Scanner;

public class CallStackValidator {

	public boolean validate(String callStack) {
		
		// you can use a Scanner to tokenize a string (that is, split it up by whitespace)
		// the next() method returns the next token
		// the hasNext() method returns true if there is anything left in the string
		// an example follows:
		Scanner s = new Scanner(callStack);
		while (s.hasNext()) {
			System.out.println(s.next());
		}

		return false;
		// don't worry about closing the scanner
	}

}
