package lab13_starter;

import java.util.Arrays;
import java.util.Comparator;

public class Demo {
	
	// Merge contents of arrays S1 and S2 into properly sized array S.
	public static <K> void merge(K[] S1, K[] S2, K[] S, Comparator<K> comp) {
	}
	
	// Sort contents of array S
	public static <K> void mergeSort(K[ ] S, Comparator<K> comp) {
	}
	
	public static void main(String[] args) {

		Comparator<String> natural = Comparator.naturalOrder();
		Comparator<String> length = new LengthComparator();
		
		// here's a small demo to test your implementations
		String[] a = {"Bob", "Sally", "Allison"};
		mergeSort(a, natural);
		System.out.println(Arrays.toString(a));
		mergeSort(a, length);
		System.out.println(Arrays.toString(a));
		
		// now do part 2 of the lab: read in file Housman.txt
		
		// sort its words alphabetically
		// sort its words by length
		// write both to files
		
	}

}
