package lab13_starter;

import java.util.Comparator;

public class LengthComparator implements Comparator<String> {
	
	public int compare(String a, String b) {
		return 0;
	}

}
