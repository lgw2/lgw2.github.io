#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "structs.h"
#include "funcs.h"

int main(void) {
    return(0);
}
